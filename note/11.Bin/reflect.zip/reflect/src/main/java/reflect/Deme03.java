package reflect;

import java.lang.reflect.Method;
import java.util.Scanner;

/**
 * JUnit 4 的原型
 */
public class Deme03 {
	public static void main(String[] args) 
		throws Exception {
		Scanner in= new Scanner(System.in); 
		System.out.print("输入类名:");
		String className = in.nextLine();
		Class cls = Class.forName(className);
		Method[] methods=
			cls.getDeclaredMethods();
		Object obj = cls.newInstance();
		for (Method method : methods) {
			//System.out.println(method);
			//检查方法method上是否包含 Test 注解
			//method.getAnnotation(被检查的注解);
			//返回值 如果为null表示方法上没有这
			//个注解, 如果返回注解类型对象,表示
			//包含注解
			if(method.getAnnotation(
				Test.class) != null){
				System.out.println("找到Test注解!");
				method.setAccessible(true); 
				method.invoke(obj);
			}
		}
	}
}





