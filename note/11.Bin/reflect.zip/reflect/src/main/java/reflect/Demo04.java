package reflect;

public class Demo04 {
	public static void main(String[] args) {
		//Girl g1 = new Girl();
		//Girl g2 = new Girl();
		//Girl g = Girl.one;
		//Girl.one = null;
		Girl g = Girl.getOne();
		Girl g1 = Girl.getOne();
		Girl g2 = Girl.getOne();
	}
}
//懒惰(懒汉式)加载的单例模式
class Boy{
	private static Boy one;
	private Boy() {
	}
	public synchronized static Boy getOne() {
		if(one == null){
			one = new Boy();
		}
		return one;
	}
}
//非懒惰(饿汉)式的单例模式
class Girl{
	private static Girl one = new Girl();
	private Girl(){
	}
	public static Girl getOne() {
		return one;
	}
}



