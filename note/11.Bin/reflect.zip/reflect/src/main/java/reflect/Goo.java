package reflect;

public class Goo {
	int age;
	String name;
	
	public void test(){
		System.out.println("test()");
	}
	public void demo(){
		System.out.println("demo()"); 
	}
}
