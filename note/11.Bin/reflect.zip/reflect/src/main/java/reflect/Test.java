package reflect;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(RetentionPolicy.RUNTIME)
//@Retention(RetentionPolicy.CLASS)
//@Retention(RetentionPolicy.SOURCE)
public @interface Test {

}
